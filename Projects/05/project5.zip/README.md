### Computer architecture

In order to test the implementation of the different chips load both the
".hdl" and its corresponding ".tst" file into the HardwareSimulator
